import React from 'react'
import './AboutUs.css'
import Header from '../../Header/Header'

export default function AboutUs() {
    return (
        <div onLoad={()=>window.scrollTo(0,0)}>
            <Header />
            <div className='fixedcontent'>
                <br />
                <div className='container'>
                    <h1>About Us</h1> <hr />
                    <div className='FooterPagecontainer shadow-lg'>
                        <div>
                            <h5>Project Group 57: CDAC</h5>
                            <p>
                               This is Cake Delivery Management System built from SpringBoot, MySql and ReactJs
                            </p>
                            <p>
                            Project Description: Automate the cake delivery process, simplifying order placement and administration. The objective is to provide a convenient and efficient way for customers to order and receive cake delivery. The project should provide an easy-to-use interface that allows customers to quickly order cakes.  The project should aim to provide a positive customer experience by ensuring fast and efficient delivery, accurate order fulfillment.

                            </p>
                        </div>
                        <hr />
                        <div>
                            <h5>Project Memebrs</h5>
                            <p>
                            230941220203- Umar Shaikh <br/>
                            230941220164- Almoiz sayyed<br/>

                            </p>
                        </div>
                        <hr />
                        <div>
                            <h5>Insititute</h5>
                            <p>
                               CDAC IACSD, Akurdi, Pune
                            </p>
                        </div>
                    </div>
                    <br />
                </div>
            </div>
        </div>
    )
}