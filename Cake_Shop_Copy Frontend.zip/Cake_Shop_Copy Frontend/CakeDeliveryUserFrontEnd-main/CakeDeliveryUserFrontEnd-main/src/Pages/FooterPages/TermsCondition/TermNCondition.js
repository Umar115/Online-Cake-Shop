import React from 'react'
import '../AboutUs/AboutUs.css'
import Header from '../../Header/Header'

export default function TermNCondition() {
    return (
        <div onLoad={() => window.scrollTo(0, 0)}>
            <Header />
            <div className='fixedcontent'>
                <br />
                <div className='container'>
                    <h1>Terms And Conditions</h1> <hr />
                    <div className='FooterPagecontainer shadow-lg'>
                        <div>
                           

                        </div>
                        <hr />
                        <div>
                            <h5>Menu</h5>
                          
                        </div>
                        <hr />
                 
                    </div>
                    <br />
                </div>
            </div>
        </div>
    )
}