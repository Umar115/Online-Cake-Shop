package com.CakeShop.services;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.CakeShop.dao.ItemDao;
import com.CakeShop.dao.ItemImageDao;
import com.CakeShop.dao.ToppingDao;
import com.CakeShop.dao.ToppingImageDao;
import com.CakeShop.dto.ApiResponse;
import com.CakeShop.entities.Item;
import com.CakeShop.entities.ItemImage;
import com.CakeShop.entities.ToppingImages;
import com.CakeShop.entities.Toppings;
import com.app.custom_exceptions.ResourceNotFoundException;

@Service
@Transactional
public class ImageHandlerService {

	@Value("${cake.upload.folder}")
	private String cakeImageFolder;
	@Value("${topping.upload.folder}")
	private String toppingImageFolder;
	
	@Autowired 
	private ItemDao itemDao;
	@Autowired
	private ItemImageDao itemImgDao;
	
	@Autowired
	private ToppingDao toppingDao;
	@Autowired
	private ToppingImageDao toppingImgDao;
	

	@PostConstruct
	public void myInit() {
		System.out.println("in myInit " + cakeImageFolder);
		// chk of folder exists --o.w create one!
		File cakeImagePath = new File(cakeImageFolder);
		File toppingImagePath=new File(toppingImageFolder);
		if (!cakeImagePath.exists()) {
			cakeImagePath.mkdirs();
		}
		if(!toppingImagePath.exists()) {
			toppingImagePath.mkdirs();
		}
		else {
			System.out.println("folders alrdy exists....");
		}

	}

	public ApiResponse uploadCakeImage(int Id, MultipartFile imageFile) throws IOException {
		Item cake = itemDao.findByItemid(Id)
				.orElseThrow(() -> new ResourceNotFoundException("InValid cake Id !!!!!"));
		String targetPath = cakeImageFolder + File.separator + "cake" + cake.getItemid()+ "."
				+ imageFile.getOriginalFilename().split("\\.")[1];
		System.out.println("Cake Image Path : " + targetPath);
		ItemImage img=new ItemImage();
		Files.copy(imageFile.getInputStream(), Paths.get(targetPath), StandardCopyOption.REPLACE_EXISTING);
		img.setData(targetPath);
		img.setItem(cake);
		itemImgDao.save(img);
		
		return new ApiResponse("Cake Image Uploaded Sucessfully !!!");
	}
	
	public ApiResponse uploadToppingImage(int Id, MultipartFile imageFile) throws IOException {
		Toppings topping= toppingDao.findByToppingId(Id)
				.orElseThrow(() -> new ResourceNotFoundException("InValid topping Id !!!!!"));
		String targetPath = toppingImageFolder + File.separator + "topping" + topping.getToppingId()+ "."
				+ imageFile.getOriginalFilename().split("\\.")[1];
		System.out.println("Topping Image Path : " + targetPath);
		ToppingImages img=new ToppingImages();
		Files.copy(imageFile.getInputStream(), Paths.get(targetPath), StandardCopyOption.REPLACE_EXISTING);
		img.setData(targetPath);
		img.setToppings(topping);
		toppingImgDao.save(img);
		
		return new ApiResponse("Cake Image Uploaded Sucessfully !!!");
	}
	
	public byte[] getCakeImage(int itemId) throws IOException {
		
		ItemImage cake = itemImgDao.findByItemId(itemId);
		String path = cake.getData();
		if (path == null) {
			throw new ResourceNotFoundException("Image does Not Exists !!!!");
		}
		return Files.readAllBytes(Paths.get(path));
	}
	
	public byte[] getToppingImage(int toppingId) throws IOException {
		ToppingImages toppingimg = toppingImgDao.findById(toppingId)
				.orElseThrow(() -> new ResourceNotFoundException("InValid topping Id !!!!!"));
		String path = toppingimg.getData();
		if (path == null) {
			throw new ResourceNotFoundException("Image does Not Exists !!!!");
		}
		return Files.readAllBytes(Paths.get(path));
	}

}
