package com.CakeShop.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CakeShop.entities.Payments;

public interface PaymentDao extends JpaRepository<Payments, Integer>{

}
