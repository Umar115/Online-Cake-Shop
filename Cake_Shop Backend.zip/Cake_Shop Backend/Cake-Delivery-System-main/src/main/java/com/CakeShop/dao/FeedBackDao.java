package com.CakeShop.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CakeShop.entities.Feedback;

public interface FeedBackDao extends JpaRepository<Feedback, Integer>{

   
}