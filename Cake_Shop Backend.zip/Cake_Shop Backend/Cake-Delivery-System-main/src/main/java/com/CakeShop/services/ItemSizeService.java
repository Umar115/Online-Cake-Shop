package com.CakeShop.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.CakeShop.dao.ItemDao;
import com.CakeShop.dao.ItemSizeDao;
import com.CakeShop.dto.ItemSizeDto;
import com.CakeShop.entities.ItemSize;
import com.app.custom_exceptions.ResourceNotFoundException;

@Service
@Transactional
public class ItemSizeService {
	@Autowired
	private ItemSizeDao itemSizeDao;
	@Autowired
	private ItemDao itemDao;
	
	//show by sizeId
	public List<ItemSize> SizeOfCake(String size, int itemId){
		List<ItemSize> thisSize = itemSizeDao.getSizeOfCake(size, itemId);
		return thisSize;
	}
	
	public ItemSize addItemSize(ItemSizeDto itemSizeDto) {
		ItemSize itemSize = new ItemSize();
		itemSize.setItem(itemDao.findById(itemSizeDto.getItemId()).orElseThrow(()->
			new ResourceNotFoundException("item with "+itemSizeDto.getItemId()+" not available")));
		itemSize.setPrice(itemSizeDto.getPrice());
		itemSize.setSize(itemSizeDto.getSize());
		itemSizeDao.save(itemSize);
		return itemSize;
	}
}