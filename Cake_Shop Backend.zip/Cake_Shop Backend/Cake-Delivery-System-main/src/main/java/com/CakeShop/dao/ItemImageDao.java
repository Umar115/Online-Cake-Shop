package com.CakeShop.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.CakeShop.entities.Cart;
import com.CakeShop.entities.Item;
import com.CakeShop.entities.ItemImage;
import com.CakeShop.entities.Users;

public interface ItemImageDao extends JpaRepository<ItemImage, Integer>{
	
	@Query(value = "select * from itemimage where itemId=?1", nativeQuery = true)
	ItemImage findByItemId(Integer itemId);
}
